package com.viewnext.apiGestionNoticias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionNoticiasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionNoticiasApplication.class, args);
		System.out.println("** GESTION DE TEMAS Y USUARIOS");
	}

}
