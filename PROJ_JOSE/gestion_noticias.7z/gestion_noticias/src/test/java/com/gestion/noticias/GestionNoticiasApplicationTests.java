package com.gestion.noticias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionNoticiasApplicationTests {
	/*
	@Test
	void contextLoads() {
	} */
}
